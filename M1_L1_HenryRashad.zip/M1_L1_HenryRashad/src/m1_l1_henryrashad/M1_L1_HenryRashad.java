/**
* A program that displays "Hello World!" to the user
* 30 January 2018
* CSC 151 Tutorial 1 - My First Java Program
* @author Rashad Henry
*/ 
package m1_l1_henryrashad;
public class M1_L1_HenryRashad 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        //Display "Hello World!" to the user
        System.out.println("Hello World!");
    }
}