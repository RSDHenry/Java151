/**
* This program accumulates the total pay 
* for someone in penny amount over the 
* number of days worked in a calendar month.
* 10 April 2018
* CSC 151 Tutorial 4 - Pennies for Pay Problem
* @Rashad Henry
*/
package penniesforpay_rashadhenry;
import java.util.Scanner;
import java.text.DecimalFormat;

public class PenniesForPay_RashadHenry {

    
    public static void main(String[] args) {
        int pennies_RWH;        // Penny accumulator
        int totalPay_RWH;       // Total pay accumulator
        int maxDays_RWH;        // Max number of days
        int dayCount_RWH;       // Day counter
        
        // Create a Scanner object for keyboard input.
        Scanner keyboard = new Scanner(System.in);
        
        // Get the maximum number of days.
        System.out.print("For how many days will you work? ");
        maxDays_RWH = keyboard.nextInt();
        
        // Validate the input.
        while (maxDays_RWH < 1)
        {
            // Prompt the user to enter a correct value.
            System.out.println("The number of days must be at least 1.");
            System.out.print("Enter the number of days: ");
            maxDays_RWH = keyboard.nextInt();    
        }
        
        // Initialize the day counter to day 1.
        dayCount_RWH = 1;
        
        // Initialize the penny accumulator for
        // the first day at work.
        pennies_RWH = 1;
        
        // Initialize the total pay accumulator.
        totalPay_RWH = 0;
        
        // Display the report header.
        System.out.println();
        System.out.println("Day\t\tPennies Earned");
        System.out.println("-------------------------------");
        
        // Display the income report.
        while (dayCount_RWH <= maxDays_RWH)
        {
           // Display the day number and pennies earned
            System.out.println(dayCount_RWH + "\t\t" + pennies_RWH);
            
            // Accumulate the total pay.
            totalPay_RWH += pennies_RWH;
            
            // Increment dayCount_RWH for the next day.
            dayCount_RWH++;
            
            // Double the number of pennies.
            pennies_RWH *= 2;
        }
        
        // Create a DecimalFormat object to format output.
        DecimalFormat dollar = new DecimalFormat("#,##0.00");
        
        // Display the total pay.
        System.out.println("Total pay: $" 
                + dollar.format(totalPay_RWH / 100.0));
    }   
}
