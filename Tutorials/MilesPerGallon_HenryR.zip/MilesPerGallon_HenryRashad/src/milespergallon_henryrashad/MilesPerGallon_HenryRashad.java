/**
* This program calculates the miles per gallon
* 6 MARCH 2018
* CSC 151 Tutorial 2 - Miles-per-Gallon Problem
* @ henryr6493
*/
package milespergallon_henryrashad;

import java.util.Scanner;

public class MilesPerGallon_HenryRashad {

    public static void main(String[] args) {
        // Declare variables
        double miles_RWH;          // Miles driven
        double gallons_RWH;        // Gallons used
        double mpg_RWH;            // Miles-per-gallon
        
        // Create a scanner object for keyboard input.
        Scanner keyboard = new Scanner(System.in);
        
        // Prompt the user to enter the miles driven.
        System.out.print("Enter the miles driven: ");
        miles_RWH = keyboard.nextDouble();
        
        // Prompt the user to enter the gallons used.
        System.out.print("Enter the gallons used: ");
        gallons_RWH = keyboard.nextDouble();
        
        // Calculate miles-per-gallon.
        mpg_RWH = miles_RWH / gallons_RWH;
        
        // Display the miles-per-gallon.
        System.out.println("The MPG is " + mpg_RWH);
   }   
}
