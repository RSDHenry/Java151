/*
* Rashad Henry
* 27 FEB 2018
* CSC 151
* This program calculates stock transactions
*/
package stocktransactionprogram_henryrashad;

import javax.swing.JOptionPane;
import java.text.DecimalFormat;

/**
 *
 * @author henryr6493
 */
public class StockTransactionProgram_HenryRashad {
    
    
    public static void main(String[] args) {
        // SET CONSTANT VARIABLE
        final double COMMISSION_RATE = 0.02;
        
        // Declare the variables.
        String userInputString_RH;          // Holds the user input
        double buyingPricePerShare_RH;      // Buying price per share
        double sellingPricePerShare_RH;     // Selling price per share
        double amountPaidForStock_RH;       // The amount paid for stock
        double amountReceivedForStock_RH;   // The amount received for stock
        double totalProfit_RH;              // Holds the total profit
        double commissionForBuying_RH;      // Commission paid to Stockbroker
        double commissionForSelling_RH;     // Commission paid for selling 
        int    numberOfSharesBought_RH;     // The number of shares purchased
        int    numberOfSharesSold_RH;       // The number of shares sold
        
        /* 
         * Prompt user for input
         * And convert String input to 
         * a double or integer where appropriate
         */
        
        userInputString_RH = JOptionPane.showInputDialog("Price per share when "
                + "stock was purchased: ");
        buyingPricePerShare_RH = Double.parseDouble(userInputString_RH);
        
        userInputString_RH = JOptionPane.showInputDialog("Enter the number of "
                + "shares purchased: ");
        numberOfSharesBought_RH = Integer.parseInt(userInputString_RH);
        
        userInputString_RH = JOptionPane.showInputDialog("Price per share when "
                + "stock was sold: ");
        sellingPricePerShare_RH = Double.parseDouble(userInputString_RH);
        
        userInputString_RH = JOptionPane.showInputDialog("Enter the number of "
                + "shares sold: ");
        numberOfSharesSold_RH = Integer.parseInt(userInputString_RH);
        
        // Calculate the amount paid for stock purchased.
        amountPaidForStock_RH = (buyingPricePerShare_RH * 
                numberOfSharesBought_RH);
        // Calculate the commission made from buying the stock.
        commissionForBuying_RH = (COMMISSION_RATE * amountPaidForStock_RH);
        // Calculate the amount of money received for the stock.
        amountReceivedForStock_RH = (numberOfSharesSold_RH * 
                sellingPricePerShare_RH);
        // Calculate the commission made from selling the stock.
        commissionForSelling_RH = (COMMISSION_RATE * amountReceivedForStock_RH);
        // Calculate the total amount gained or lost through stocks.
        totalProfit_RH = (amountReceivedForStock_RH - amountPaidForStock_RH)
                - (commissionForSelling_RH + commissionForBuying_RH);
        
        // Display totals to user
        if (totalProfit_RH < 0)
        {
            DecimalFormat myFormat = new DecimalFormat("$#,##0.00;$-#,##0.00");
            JOptionPane.showMessageDialog(null, "You paid "  
                + myFormat.format(amountPaidForStock_RH) + " for stock" 
                + "\nYou paid " + myFormat.format(commissionForBuying_RH)
                + " in commission to Broker"
                + "\nYou received " + myFormat.format(amountReceivedForStock_RH)
                + " for selling stock"
                + "\nYou paid " + myFormat.format(commissionForSelling_RH)
                + " in commission to Broker"
                + "\nYour recent transactions resulted in a net loss of "
                + myFormat.format(totalProfit_RH));
        }
        else
        {
        DecimalFormat myFormat = new DecimalFormat("$#,##0.00;$-#,##0.00");
        JOptionPane.showMessageDialog(null, "You paid "  
                + myFormat.format(amountPaidForStock_RH) + " for stock" 
                + "\nYou paid " + myFormat.format(commissionForBuying_RH)
                + " in commission to Broker"
                + "\nYou received " + myFormat.format(amountReceivedForStock_RH)
                + " for selling stock"
                + "\nYou paid " + myFormat.format(commissionForSelling_RH)
                + " in commission to Broker"
                + "\nYour final transaction profit is: " 
                + myFormat.format(totalProfit_RH));
        }
    }    
}