/**
* This program takes user input and adds the
* sum of all the numbers from the number entered
* in a loop to display the total.
 * 17 April 2018
* CSC 151 Programming Challenges: Sum of Numbers
* @Rashad Henry
*/

package sumofnumbers_henryrashad;
import java.util.Scanner;

public class SumOfNumbers_HenryRashad {

    public static void main(String[] args) {
        // Declare variables.
        String userInput_RWH;       // Hold user input.
        int userNum_RWH;            // Hold the number entered by the user.
        int total_RWH;              // Accumulator.
        int numCounter_RWH;         // Set the number counter.
        
        // Create scanner object for keyboard input.
        Scanner keyboard = new Scanner(System.in);
        
        // Get a number from the user.
        System.out.println("Enter a positive nonzero number: ");
        userInput_RWH = keyboard.next();
        
        // Convert user input string to an int.
        userNum_RWH = Integer.parseInt(userInput_RWH);
        
        // Validate the input.
        while (userNum_RWH < 1)
        {
            System.out.println("Invalid. The number must be greater than 1.");
            System.out.print("Enter a positive nonzero number: ");
            userNum_RWH = keyboard.nextInt();
        }
        
        // Set the accumulator to 0.
        total_RWH = 0;
        
        // Set the number counter to 1.
        //numCounter_RWH = 1;
        
        // Display the total accumulated value.
        for (numCounter_RWH = 1; numCounter_RWH <= userNum_RWH; 
                numCounter_RWH++)
        {
            // Accumulate the total.
            total_RWH += userNum_RWH;
        }
        
        // Display the accumulated total to the user.
        System.out.println("The sum of " + userInput_RWH + " plus all "
                + "the numbers in between is " + total_RWH);
    }    
}