/*
* Rashad Henry
* 6 MARCH 2018
* CSC 151
* This takes three test scores and calculates the average
*/
package testaverage_henryrashad;

import java.util.Scanner;

public class TestAverage_HenryRashad {

    public static void main(String[] args) {
        // Declare the variables.
        double test1;                   // Hold the score for test #1.
        double test2;                   // Hold the score for test #2.
        double test3;                   // Hold the score for test #3.
        double testAverage;             // Hold the average score.
        
        // Create a scanner object for user input.
        Scanner keyboard = new Scanner(System.in);
        
        // Prompt user to enter the score of test #1.
        System.out.print("Enter the score for Test 1: ");
        test1 = keyboard.nextDouble();
        
        // Prompt user to enter the score of test #2.
        System.out.print("Enter the score for Test 2: ");
        test2 = keyboard.nextDouble();
        
        // Prompt the user to enter the score of test #3.
        System.out.print("Enter the score for Test 3: ");
        test3 = keyboard.nextDouble();
        
        // Calculate the average of the three test scores.
        testAverage = (test1 + test2 + test3) / 3;
        
        // Display the three test scores to the user.
        System.out.printf("\nScore for Test 1: "
                + test1 + "\n" + "Score for Test 2: " + test2 + "\n"
                + "Score for Test 3: " + test3 + "\n" + "\nThe Test "
                + "Average is: %.2f \n", testAverage);
   }    
}