/**
* This is a modification of the 
* Internet Service Provider program. This modification
* will display the total in savings a customer
* would of made if they switched to a different package
* 27 MARCH 2018
* CSC 151 Homework 3 - Internet Service Provider
*/
package internetserviceproviderpart2_henryrashad;
import java.util.Scanner;

/**
 *
 * @author Rashad
 */
public class InternetServiceProviderPart2_HenryRashad {

    public static void main(String[] args) {
        
     // Declare constant variables
        final double PACKAGE_A_PRICE_RWH = 9.95;
        final double PACKAGE_B_PRICE_RWH = 13.95;
        final double PACKAGE_C_PRICE_RWH = 19.95;
        final int PACKAGE_A_HRS_ACCESS_RWH = 10;
        final int PACKAGE_B_HRS_ACCESS_RWH = 20;
        final double PACKAGE_A_EXTRA_FEE_RWH = 2.00;
        final double PACKAGE_B_EXTRA_FEE_RWH = 1.00;
        
        // Declare local variables
        String userInputPackage_RWH;
        int userInputHours_RWH;
        int additionalHours_RWH = 0;
        int additionalHoursCompare_RWH = 0;
        double additionalCharge_RWH = 0;
        double additionalChargeCompare_RWH = 0;
        double totalBill_RWH = 0;
        double packageBPricingCompare_RWH = 0;
        double packageBSavings_RWH = 0;
        double packageCSavings_RWH = 0;
        
        Scanner scanner = new Scanner(System.in);
        
        // Prompt user for service package they currently own.
        System.out.println("Which service package do you have?: ");
        userInputPackage_RWH = scanner.nextLine();
        
        // Prompt user for internet hours used.
        System.out.println("How many service hours did you use this month?: ");
        userInputHours_RWH = scanner.nextInt();
        
        // Nested If and If-Else-If statements to determine monthly charges.
        if(userInputPackage_RWH.equalsIgnoreCase("a")) {
            if(userInputHours_RWH > PACKAGE_A_HRS_ACCESS_RWH) {
                additionalHours_RWH = userInputHours_RWH - 
                PACKAGE_A_HRS_ACCESS_RWH;
                additionalCharge_RWH = additionalHours_RWH * 
                PACKAGE_A_EXTRA_FEE_RWH;
            }
            // Total charges for Package A.
            totalBill_RWH = PACKAGE_A_PRICE_RWH + additionalCharge_RWH;
            
            // Calculate the charges for package B.
            if(userInputHours_RWH > PACKAGE_B_PRICE_RWH) {
                additionalHoursCompare_RWH = userInputHours_RWH
                        - PACKAGE_B_HRS_ACCESS_RWH;
                additionalChargeCompare_RWH = additionalHoursCompare_RWH
                        * PACKAGE_B_EXTRA_FEE_RWH;
            }
            // Compare the savings if any for Package B.
            packageBPricingCompare_RWH = PACKAGE_B_PRICE_RWH
                    + additionalChargeCompare_RWH;
            if(packageBPricingCompare_RWH < totalBill_RWH) {
                packageBSavings_RWH = totalBill_RWH 
                        - packageBPricingCompare_RWH;
                System.out.println("If you switch to Package B,"
                        + " you would have saved: $" + packageBSavings_RWH);
            }
            // Compare the savings if any for Package C.
            if(PACKAGE_C_PRICE_RWH < totalBill_RWH) {
                packageCSavings_RWH = totalBill_RWH - PACKAGE_C_PRICE_RWH;
                System.out.println("If you switch to Package C,"
                        + " you have saved: $" + packageCSavings_RWH);
            }
            
            // Determine monthly charges for Package B.
        } else if(userInputPackage_RWH.equalsIgnoreCase("b")) {
            if(userInputHours_RWH > PACKAGE_B_HRS_ACCESS_RWH) {
                additionalHours_RWH = userInputHours_RWH 
                        - PACKAGE_B_HRS_ACCESS_RWH;
                additionalCharge_RWH = additionalHours_RWH 
                        * PACKAGE_B_EXTRA_FEE_RWH;
            }
            // Total charges for Package B.
            totalBill_RWH = PACKAGE_B_PRICE_RWH + additionalCharge_RWH;
            
            // Compare the savings if any for Package C.
            if(PACKAGE_C_PRICE_RWH < totalBill_RWH) {
                packageCSavings_RWH = totalBill_RWH - PACKAGE_C_PRICE_RWH;
                System.out.println("If you switch to Package C,"
                        + " you would have saved: $" + packageCSavings_RWH);
            }
            
            // Determine the monthly charges for Package C.
        } else if(userInputPackage_RWH.equalsIgnoreCase("c")) {
            totalBill_RWH = PACKAGE_C_PRICE_RWH;
        }
        
            // Display the monthly charges to the user.
        System.out.println("Your total charges for the month is: $"
                + totalBill_RWH);
        }
}